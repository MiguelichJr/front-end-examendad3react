
export const API_BASE_URL = 'https://backend-examendad2-laravel.herokuapp.com/api';
//export const API_BASE_URL = 'http://localhost:8086/api';